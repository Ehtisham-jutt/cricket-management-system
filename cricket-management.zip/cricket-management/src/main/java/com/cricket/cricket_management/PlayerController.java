
package com.cricket.cricket_management;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/players")
@CrossOrigin
public class PlayerController {

    PlayerLinkedList list = new PlayerLinkedList();

    @GetMapping
    public ArrayList<player> getAll() {
        return list.getAll();
    }

    @PostMapping
    public String add(@RequestBody player p) {
        list.add(p);
        return "Player Added";
    }

    @PutMapping("/{id}")
    public String update(@PathVariable int id, @RequestBody player p) {
        return list.update(id, p.getName(), p.getCountry(), p.getRuns())
                ? "Updated" : "Not Found";
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable int id) {
        return list.delete(id) ? "Deleted" : "Not Found";
    }
}

