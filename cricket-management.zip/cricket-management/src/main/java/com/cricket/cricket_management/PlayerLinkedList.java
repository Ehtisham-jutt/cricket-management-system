
package com.cricket.cricket_management;

import java.util.ArrayList;

public class PlayerLinkedList {

    Node head;

    public void add(player p) {
        Node n = new Node(p);

        if (head == null) {
            head = n;
        } else {
            Node t = head;
            while (t.next != null)
                t = t.next;
            t.next = n;
        }
    }

    public ArrayList<player> getAll() {
        ArrayList<player> list = new ArrayList<>();
        Node t = head;

        while (t != null) {
            list.add(t.data);
            t = t.next;
        }
        return list;
    }

    public boolean update(int id, String name, String country, int runs) {
        Node t = head;

        while (t != null) {
            if (t.data.getId() == id) {
                t.data.setName(name);
                t.data.setCountry(country);
                t.data.setRuns(runs);
                return true;
            }
            t = t.next;
        }
        return false;
    }

    public boolean delete(int id) {
        if (head == null) return false;

        if (head.data.getId() == id) {
            head = head.next;
            return true;
        }

        Node t = head;

        while (t.next != null) {
            if (t.next.data.getId() == id) {
                t.next = t.next.next;
                return true;
            }
            t = t.next;
        }
        return false;
    }
}
