
package com.cricket.cricket_management;

public class Node {

    player data;
    Node next;

    public Node(player data) {
        this.data = data;
        this.next = null;
    }
}

