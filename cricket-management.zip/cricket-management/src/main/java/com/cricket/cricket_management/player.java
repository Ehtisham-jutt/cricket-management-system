
package com.cricket.cricket_management;

public class player {

    private int id;
    private String name;
    private String country;
    private int runs;

    public player(int id, String name, String country, int runs) {
        this.id = id;
        this.name = name;
        this.country = country;
        this.runs = runs;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getCountry() { return country; }
    public int getRuns() { return runs; }

    public void setName(String name) { this.name = name; }
    public void setCountry(String country) { this.country = country; }
    public void setRuns(int runs) { this.runs = runs; }
}